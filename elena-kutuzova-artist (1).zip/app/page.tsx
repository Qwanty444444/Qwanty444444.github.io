"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { Playfair_Display } from 'next/font/google'
import { Globe, Menu, X, Send, Mail } from 'lucide-react'

const playfair = Playfair_Display({
  subsets: ["latin", "cyrillic"],
  weight: ["300", "400", "500"],
  style: ["normal", "italic"],
  display: "swap",
})

export default function ArtistPortfolio() {
  const [scrollProgress, setScrollProgress] = useState(0)
  const [showOverlay, setShowOverlay] = useState(false)
  const [language, setLanguage] = useState<"ru" | "en">("ru")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const heroRef = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  const translations = {
    ru: {
      portfolio: "Портфолио",
      exhibitions: "Выставки",
      about: "Об авторе",
      contact: "Контакты",
      artistName: "Елена Кутузова",
      artistTitle: "Современная художница",
      artistDescription: "Исследование скрытых измерений реальности через картины с двойным изображением",
      scrollText: "Прокрутите, чтобы исследовать скрытые слои искусства",
      biography: "Биография",
      artistStatement: "Творческое кредо",
      bioText1:
        "Елена Кутузова — единственный в мире художник, работающий в технике двойного изображения. Она пишет флуоресцентными красками, раскрывая две истории на одном холсте: одна история при обычном свете, а вторая при ультрафиолете. Так, на одном полотне соседствуют два разных мира.",
      bioText2:
        "Музыка является неотъемлемой частью восприятия и продолжением визуального ряда. Лампы и кинетические объекты, повторяющие сюжет картин, делают экспозицию объемной и нарушают вертикальное пространство полотна, вынося сюжет в пространство зрителя. Благодаря искусству двойного изображения, возникает мир, в котором статичное становится динамичным.",
      bioText3:
        "Уникальность ее картин в том, что краски, которыми она творит, Елена изготавливает сама, а оживление ее картин происходит под воздействием ультрафиолетовых лучей.",
      bioText4:
        "Елена Кутузова награждена медалью В. Кандинского от «Европейской Академии Естественных Наук» за особый вклад в мировое изобразительное искусство. Орденом «Холодного света» за создание картин, выполненных люминесцентными красками, за создание люминесцентных красок для художественных работ.",
      bioText5:
        "Имеет четыре патента РФ (технология и краски). Победитель в номинации «Экспериментальное искусство» в проекте ART-WEEK, Москва. Статья в Биографической энциклопедии успешных людей в России «WHO IS WHO В РОССИИ». Работы Елены Кутузовой хранятся в частных собраниях России, Германии, Англии, Индии, Америки, Израиля, Австрии.",
      quote:
        "Я рисую светом как средством. Каждая работа хранит секреты, которые раскрываются только при разном освещении, приглашая зрителей задаться вопросом о том, что скрывается под поверхностью реальности.",
      contactText:
        "По вопросам выставок, заказов или для знакомства с двойственной природой моих работ лично, пожалуйста, свяжитесь со мной.",
      telegram: "Телеграм канал",
      email: "Электронная почта",
      hiddenLayers: "Скрытые слои",
      dualArtwork: "Картина с двойным изображением",
      lightShadow: "Свет и тень",
      hiddenDepths: "Скрытые глубины",
      dualRealities: "Двойные реальности",
      luminousVisions: "Светящиеся видения",
    },
    en: {
      portfolio: "Portfolio",
      exhibitions: "Exhibitions",
      about: "About",
      contact: "Contact",
      artistName: "Elena Kutuzova",
      artistTitle: "Contemporary Artist",
      artistDescription: "Exploring the hidden dimensions of reality through dual-imagery paintings",
      scrollText: "Scroll to explore the hidden layers of art",
      biography: "Biography",
      artistStatement: "Artistic Statement",
      bioText1:
        "Elena Kutuzova is the world's only artist working in the dual-imagery technique. She paints with fluorescent paints, revealing two stories on one canvas: one story under ordinary light, and the second under ultraviolet light. Thus, two different worlds coexist on one canvas.",
      bioText2:
        "Music is an integral part of perception and a continuation of the visual series. Lamps and kinetic objects that repeat the plot of the paintings make the exposition voluminous and disrupt the vertical space of the canvas, bringing the plot into the viewer's space. Thanks to the art of dual imagery, a world emerges in which the static becomes dynamic.",
      bioText3:
        "The uniqueness of her paintings lies in the fact that Elena makes the paints she creates with herself, and the revival of her paintings occurs under the influence of ultraviolet rays.",
      bioText4:
        "Elena Kutuzova was awarded the V. Kandinsky medal from the 'European Academy of Natural Sciences' for her special contribution to world fine art. The Order of 'Cold Light' for creating paintings made with luminescent paints, for creating luminescent paints for artistic works.",
      bioText5:
        "She holds four RF patents (technology and paints). Winner in the 'Experimental Art' category in the ART-WEEK project, Moscow. Article in the Biographical Encyclopedia of Successful People in Russia 'WHO IS WHO IN RUSSIA'. Elena Kutuzova's works are kept in private collections in Russia, Germany, England, India, America, Israel, Austria.",
      quote:
        "I paint with light itself as my medium. Each work holds secrets that reveal themselves only when illuminated differently, inviting viewers to question what lies beneath the surface of reality.",
      contactText:
        "For inquiries about exhibitions, commissions, or to experience the dual nature of my work in person, please reach out.",
      telegram: "Telegram Channel",
      email: "Email",
      hiddenLayers: "Hidden Layers",
      dualArtwork: "Dual-imagery painting",
      lightShadow: "Light & Shadow",
      hiddenDepths: "Hidden Depths",
      dualRealities: "Dual Realities",
      luminousVisions: "Luminous Visions",
    },
  }

  const t = translations[language]

  useEffect(() => {
    const handleScroll = () => {
      if (!heroRef.current || !containerRef.current) return

      const heroHeight = heroRef.current.offsetHeight
      const scrollTop = window.scrollY
      const progress = Math.min(scrollTop / (heroHeight * 0.5), 1) // Ускорили анимацию

      setScrollProgress(progress)
      setShowOverlay(progress > 0.8)
    }

    window.addEventListener("scroll", handleScroll)
    handleScroll()

    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Generate particle positions for sunlight dust effects
  const particles = Array.from({ length: 40 }, (_, i) => ({
    id: i,
    left: 15 + Math.random() * 70,
    top: 10 + Math.random() * 80,
    size: Math.random() * 3 + 1,
    speed: Math.random() * 4 + 6,
    opacity: Math.random() * 0.6 + 0.3,
  }))

  return (
    <div ref={containerRef} className={`${playfair.className} bg-black text-white`}>
      {/* Header Navigation - Malika Favre Style */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg border-b border-gray-100">
        <div className="w-full px-2 sm:px-4 md:px-4 py-3 md:py-4">
          <div className="flex items-center justify-between max-w-5xl mx-auto">
            {/* Logo/Artist Name - всегда показывается слева */}
            <div className="flex items-center flex-shrink-0">
              <h1 className="text-base sm:text-lg md:text-xl lg:text-2xl font-light tracking-wider text-gray-900 truncate">
                {t.artistName}
              </h1>
            </div>

            {/* Navigation Menu */}
            <nav className="hidden md:flex items-center space-x-4 lg:space-x-8 xl:space-x-12">
              <a
                href="#portfolio"
                className="text-gray-700 hover:text-gray-900 transition-colors duration-300 text-sm font-light tracking-wide uppercase whitespace-nowrap"
              >
                {t.portfolio}
              </a>
              <a
                href="#exhibitions"
                className="text-gray-700 hover:text-gray-900 transition-colors duration-300 text-sm font-light tracking-wide uppercase whitespace-nowrap"
              >
                {t.exhibitions}
              </a>
              <a
                href="#about"
                className="text-gray-700 hover:text-gray-900 transition-colors duration-300 text-sm font-light tracking-wide uppercase whitespace-nowrap"
              >
                {t.about}
              </a>
              <a
                href="#contact"
                className="text-gray-700 hover:text-gray-900 transition-colors duration-300 text-sm font-light tracking-wide uppercase whitespace-nowrap"
              >
                {t.contact}
              </a>
              
              {/* Language Toggle in Header */}
              <button
                onClick={() => setLanguage(language === "ru" ? "en" : "ru")}
                className="flex items-center space-x-2 text-gray-700 hover:text-gray-900 transition-colors duration-300 text-sm font-light tracking-wide uppercase whitespace-nowrap"
              >
                <Globe className="w-4 h-4 flex-shrink-0" />
                <span>{language === "ru" ? "EN" : "RU"}</span>
              </button>
            </nav>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2 z-50 flex-shrink-0"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="w-5 h-5 text-gray-700" />
              ) : (
                <Menu className="w-5 h-5 text-gray-700" />
              )}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden absolute top-full left-0 right-0 bg-white/95 backdrop-blur-lg border-b border-gray-200 shadow-lg">
              <nav className="flex flex-col space-y-3 p-2 sm:p-4">
                <a
                  href="#portfolio"
                  className="text-gray-700 hover:text-gray-900 transition-colors duration-300 text-sm font-light tracking-wide uppercase py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {t.portfolio}
                </a>
                <a
                  href="#exhibitions"
                  className="text-gray-700 hover:text-gray-900 transition-colors duration-300 text-sm font-light tracking-wide uppercase py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {t.exhibitions}
                </a>
                <a
                  href="#about"
                  className="text-gray-700 hover:text-gray-900 transition-colors duration-300 text-sm font-light tracking-wide uppercase py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {t.about}
                </a>
                <a
                  href="#contact"
                  className="text-gray-700 hover:text-gray-900 transition-colors duration-300 text-sm font-light tracking-wide uppercase py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {t.contact}
                </a>
                <button
                  onClick={() => {
                    setLanguage(language === "ru" ? "en" : "ru")
                    setMobileMenuOpen(false)
                  }}
                  className="flex items-center space-x-2 text-gray-700 hover:text-gray-900 transition-colors duration-300 text-sm font-light tracking-wide uppercase text-left py-2"
                >
                  <Globe className="w-4 h-4" />
                  <span>{language === "ru" ? "EN" : "RU"}</span>
                </button>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section - Scroll with page */}
      <section ref={heroRef} className="relative h-[150vh] md:h-[250vh] pt-16 md:pt-20">
        {/* Dynamic Background that follows scroll */}
        <div
          className="absolute inset-0 transition-all duration-500 ease-out pointer-events-none"
          style={{
            background: `radial-gradient(ellipse 120% 100% at center, 
        rgba(${30 - 30 * scrollProgress}, ${15 - 15 * scrollProgress}, ${60 - 60 * scrollProgress}, ${0.95 - 0.95 * scrollProgress}) 0%, 
        rgba(${20 - 20 * scrollProgress}, ${10 - 10 * scrollProgress}, ${40 - 40 * scrollProgress}, ${0.8 - 0.8 * scrollProgress}) 30%, 
        rgba(${255 * scrollProgress}, ${255 * scrollProgress}, ${255 * scrollProgress}, 1) 100%)`,
          }}
        />

        {/* Sunlight Beam Effect */}
        <div
          className="absolute pointer-events-none"
          style={{
            left: typeof window !== 'undefined' && window.innerWidth < 768 ? '0.5rem' : '0',
            right: typeof window !== 'undefined' && window.innerWidth < 768 ? '0.5rem' : '0',
            top: '0',
            bottom: '0',
            background: `linear-gradient(${120 + scrollProgress * 40}deg, 
transparent ${40 - scrollProgress * 30}%, 
rgba(${255}, ${250}, ${230}, ${0.4 * scrollProgress}) ${50 - scrollProgress * 15}%, 
rgba(${255}, ${245}, ${200}, ${0.6 * scrollProgress}) ${60}%, 
rgba(${255}, ${240}, ${180}, ${0.5 * scrollProgress}) ${70 + scrollProgress * 15}%,
transparent ${80 + scrollProgress * 15}%)`,
            opacity: scrollProgress * 0.9,
            transform: `rotate(${-20 + scrollProgress * 30}deg) scale(${1.1 + scrollProgress * 0.4})`,
          }}
        />

        {/* Floating Sunlight Particles - уменьшено количество для мобильных */}
        <div 
          className="absolute pointer-events-none overflow-hidden"
          style={{
            left: typeof window !== 'undefined' && window.innerWidth < 768 ? '0.5rem' : '0',
            right: typeof window !== 'undefined' && window.innerWidth < 768 ? '0.5rem' : '0',
            top: '0',
            bottom: '0',
          }}
        >
          {particles.slice(0, (typeof window !== 'undefined' && window.innerWidth < 768) ? 15 : 40).map((particle) => (
            <div
              key={particle.id}
              className="absolute rounded-full"
              style={{
                left: `${particle.left}%`,
                top: `${particle.top}%`,
                width: `${particle.size}px`,
                height: `${particle.size}px`,
                background: `rgba(${255}, ${245 - (245 - 220) * (1 - scrollProgress)}, ${200 - (200 - 150) * (1 - scrollProgress)}, ${particle.opacity * scrollProgress})`,
                filter: `blur(${1 + Math.random() * 1.5}px)`,
                transform: `translateY(${scrollProgress * -120 - Math.sin(particle.id + scrollProgress * 6) * 35}px) 
                     translateX(${Math.cos(particle.id + scrollProgress * 5) * 45}px) 
                     scale(${0.4 + scrollProgress * 0.9})`,
                opacity: scrollProgress * particle.opacity,
                boxShadow: `0 0 ${6 + scrollProgress * 12}px rgba(${255}, ${245}, ${200}, ${0.5 * scrollProgress})`,
                animation:
                  scrollProgress > 0.2
                    ? `float ${particle.speed}s ease-in-out infinite ${Math.random() * 4}s`
                    : "none",
              }}
            />
          ))}
        </div>

        {/* Sun Glares */}
        <div className="absolute inset-0 pointer-events-none">
          {[1, 2, 3, 4, 5].map((flare) => (
            <div
              key={flare}
              className="absolute rounded-full"
              style={{
                left: `${55 + flare * 12}%`,
                top: `${15 + flare * 8}%`,
                width: `${15 + flare * 8}px`,
                height: `${15 + flare * 8}px`,
                background: `radial-gradient(circle, rgba(${255}, ${250}, ${230}, ${0.5 * scrollProgress}) 0%, transparent 70%)`,
                opacity: scrollProgress * 0.7,
                transform: `scale(${scrollProgress * (1 + flare * 0.3)})`,
                filter: `blur(${1 + flare * 0.5}px)`,
              }}
            />
          ))}
        </div>

        {/* Window Light Rays */}
        <div className="absolute inset-0 pointer-events-none">
          {[1, 2, 3].map((ray) => (
            <div
              key={ray}
              className="absolute"
              style={{
                right: `${10 + ray * 5}%`,
                top: `${5 + ray * 3}%`,
                width: `${2 + ray}px`,
                height: `${60 + ray * 20}%`,
                background: `linear-gradient(180deg, 
            rgba(${255}, ${250}, ${230}, ${0.3 * scrollProgress}) 0%, 
            rgba(${255}, ${245}, ${200}, ${0.2 * scrollProgress}) 50%, 
            transparent 100%)`,
                opacity: scrollProgress * 0.6,
                transform: `rotate(${-5 + ray * 2}deg) scaleY(${0.5 + scrollProgress * 0.8})`,
                filter: `blur(${0.5 + ray * 0.3}px)`,
              }}
            />
          ))}
        </div>

        {/* Main Painting Container - Адаптивный для мобильных */}
        <div className="sticky top-1/2 transform -translate-y-1/2 z-10">
          <div className="w-full px-2 sm:px-4 md:px-8 max-w-5xl mx-auto">
            <div
              className="relative mx-auto rounded-xl md:rounded-lg overflow-hidden"
              style={{
                aspectRatio: window.innerWidth < 768 ? '3/4' : '4/3',
                boxShadow: `0 ${15 + scrollProgress * 35}px ${50 + scrollProgress * 70}px rgba(0, 0, 0, ${0.08 + scrollProgress * 0.15})`,
              }}
            >
              {/* UV Light Version */}
              <div
                className="absolute inset-0 transition-all duration-500 ease-out"
                style={{
                  opacity: 1 - scrollProgress,
                  transform: `scale(${1 + scrollProgress * 0.015})`,
                }}
              >
                <Image
                  src="/images/uv-koi-painting.jpg"
                  alt="Мистические карпы кои под УФ-светом"
                  fill
                  className="object-cover rounded-xl md:rounded-lg"
                  style={{
                    filter: `hue-rotate(${scrollProgress * 8}deg) 
                     saturate(${1.6 - scrollProgress * 0.4}) 
                     brightness(${0.95 + scrollProgress * 0.25}) 
                     contrast(${1.2 - scrollProgress * 0.15})`,
                  }}
                  priority
                />
                <div
                  className="absolute inset-0 rounded-xl md:rounded-lg"
                  style={{
                    background: `radial-gradient(ellipse at center, 
      rgba(75, 0, 130, ${0.15 - scrollProgress * 0.15}), 
      rgba(30, 15, 60, ${0.1 - scrollProgress * 0.1}), 
      transparent 70%)`,
                    mixBlendMode: "multiply",
                  }}
                />
              </div>

              {/* Daylight Version */}
              <div
                className="absolute inset-0 transition-all duration-500 ease-out"
                style={{
                  opacity: scrollProgress,
                  transform: `scale(${0.985 + scrollProgress * 0.015})`,
                }}
              >
                <Image
                  src="/images/daylight-japanese-scene.jpg"
                  alt="Классическая японская сцена в дневном свете"
                  fill
                  className="object-cover rounded-xl md:rounded-lg"
                  style={{
                    filter: `sepia(${scrollProgress * 0.08}) 
                     saturate(${0.85 + scrollProgress * 0.35}) 
                     brightness(${0.95 + scrollProgress * 0.15}) 
                     contrast(${0.95 + scrollProgress * 0.15})`,
                  }}
                />
                <div
                  className="absolute inset-0 rounded-xl md:rounded-lg"
                  style={{
                    background: `linear-gradient(135deg, 
      rgba(255, 250, 230, ${0.12 * scrollProgress}), 
      rgba(255, 245, 200, ${0.08 * scrollProgress}), 
      rgba(255, 240, 180, ${0.04 * scrollProgress}))`,
                    mixBlendMode: "overlay",
                  }}
                />
              </div>

              {/* Elegant Frame */}
              <div
                className="absolute inset-0 border rounded-xl md:rounded-lg transition-all duration-500"
                style={{
                  borderWidth: "1px",
                  borderColor: `rgba(${120 + 135 * scrollProgress}, ${120 + 135 * scrollProgress}, ${120 + 135 * scrollProgress}, ${0.15 + 0.25 * scrollProgress})`,
                  boxShadow: `inset 0 0 ${20 + scrollProgress * 40}px rgba(${255 * scrollProgress}, ${250 * scrollProgress}, ${230 * scrollProgress}, ${0.2 * scrollProgress})`,
                }}
              />

              {/* Artist Name on Painting - оптимизировано для мобильных */}
              <div
                className="absolute inset-0 flex items-center justify-center pointer-events-none"
                style={{
                  opacity: Math.max(0, 1 - scrollProgress * 1.5), // Быстрее исчезает на мобильных
                  transform: window.innerWidth < 768 
                    ? `translateY(${scrollProgress * -200}px) scale(${1 - scrollProgress * 0.3})` // Мобильная анимация
                    : `translateY(${scrollProgress * -400}px) scale(${1 - scrollProgress * 0.2})`, // Десктопная анимация
                }}
              >
                <div className="text-center px-2 sm:px-4">
                  <h1
                    className="font-serif font-light tracking-widest text-white drop-shadow-2xl"
                    style={{
                      fontSize: window.innerWidth < 768 
                        ? `${2.5 - scrollProgress * 0.5}rem` // Динамический размер для мобильных
                        : 'clamp(2rem, 8vw, 8rem)', // Адаптивный размер для десктопа
                      textShadow: `0 0 ${30 + scrollProgress * 50}px rgba(255, 255, 255, ${0.9 + scrollProgress * 0.1})`,
                      letterSpacing: window.innerWidth < 768 ? '0.1em' : '0.05em',
                      lineHeight: '0.9',
                      wordBreak: 'keep-all',
                    }}
                  >
                    {t.artistName}
                  </h1>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section - улучшенная мобильная адаптация */}
      <section
        id="portfolio"
        className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black py-8 md:py-16 px-4"
      >
        <div className="max-w-7xl mx-auto">
          <h2 className="font-serif text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-light text-center mb-8 md:mb-12 text-white">
            {t.portfolio}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 md:gap-12">
            {/* Первая работа с реальными изображениями и 3D эффектом */}
            <div className="group relative aspect-square overflow-hidden rounded-2xl perspective-1000">
              <div className="relative w-full h-full transform-style-preserve-3d group-hover:rotate-y-180 transition-transform duration-1000">
                {/* Дневная версия (лицевая сторона) */}
                <div className="absolute inset-0 backface-hidden">
                  <Image
                    src="/images/daylight-artwork.jpg"
                    alt="Абстрактная композиция - дневной свет"
                    fill
                    className="object-cover rounded-2xl"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  <div className="absolute bottom-4 left-4 right-4 transform translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                    <h3 className="font-serif text-lg md:text-2xl font-light text-white mb-2">Абстрактная композиция</h3>
                    <p className="text-xs md:text-sm text-white/80">{t.dualArtwork}, 2024</p>
                    <p className="text-xs text-white/60 mt-1 hidden md:block">Наведите для УФ-версии</p>
                  </div>
                </div>

                {/* УФ версия (обратная сторона) */}
                <div className="absolute inset-0 backface-hidden rotate-y-180">
                  <Image
                    src="/images/uv-artwork.jpg"
                    alt="Абстрактная композиция - УФ свет"
                    fill
                    className="object-cover rounded-2xl"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-purple-900/60 via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="font-serif text-lg md:text-2xl font-light text-white mb-2">Скрытая реальность</h3>
                    <p className="text-xs md:text-sm text-white/80">УФ-освещение</p>
                    <p className="text-xs text-white/60 mt-1">Мистическая трансформация</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Остальные работы с обычной анимацией */}
            {[2, 3, 4, 5, 6].map((item) => (
              <div key={item} className="group relative aspect-square overflow-hidden rounded-2xl">
                <Image
                  src={`/placeholder.svg?height=500&width=500&text=${t.hiddenLayers}+${item}`}
                  alt={`${t.hiddenLayers} ${item}`}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="absolute bottom-4 left-4 right-4 transform translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                  <h3 className="font-serif text-lg md:text-2xl font-light text-white mb-2">
                    {t.hiddenLayers} {item}
                  </h3>
                  <p className="text-xs md:text-sm text-white/80">{t.dualArtwork}, 2024</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Exhibitions Section */}
      <section id="exhibitions" className="min-h-screen bg-gradient-to-b from-black to-gray-900 py-12 md:py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="font-serif text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-light mb-12 md:mb-16 text-white">{t.exhibitions}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
            {[
              { title: t.lightShadow, venue: "Галерея современного искусства, Москва", year: "2024" },
              { title: t.hiddenDepths, venue: "Пространство современности, Лондон", year: "2023" },
              { title: t.dualRealities, venue: "Арт Базель, Майами", year: "2023" },
              { title: t.luminousVisions, venue: "Тейт Модерн, Лондон", year: "2022" },
            ].map((exhibition, index) => (
              <div key={index} className="group text-left">
                <div className="relative aspect-[4/3] mb-4 md:mb-6 overflow-hidden rounded-2xl">
                  <Image
                    src={`/placeholder.svg?height=300&width=400&text=${exhibition.title}`}
                    alt={exhibition.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <h3 className="font-serif text-xl md:text-3xl font-light text-white mb-2">{exhibition.title}</h3>
                <p className="text-white/80 font-light text-sm md:text-lg mb-1">{exhibition.venue}</p>
                <p className="text-white/60 font-light text-sm md:text-base">{exhibition.year}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="min-h-screen bg-black py-12 md:py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="font-serif text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-light text-center mb-12 md:mb-16 text-white">
            {t.about}
          </h2>
          
          {/* New portrait photo */}
          <div className="flex justify-center mb-12 md:mb-16">
            <div className="relative w-64 h-64 sm:w-80 sm:h-80 md:w-96 md:h-96 rounded-2xl overflow-hidden shadow-2xl">
              <Image
                src="/images/elena-portrait-tulips.jpg"
                alt="Елена Кутузова с белыми тюльпанами"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-t from-black/10 via-transparent to-transparent" />
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-16 items-center">
            <div className="relative aspect-[3/4] max-w-sm md:max-w-md mx-auto">
              <Image
                src="/images/elena-portrait.jpg"
                alt="Елена Кутузова"
                fill
                className="object-cover rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-t from-black/20 via-transparent to-transparent" />
            </div>
            <div className="space-y-6 md:space-y-8">
              <div>
                <h3 className="font-serif text-2xl md:text-4xl font-light mb-4 md:mb-6 text-white">{t.biography}</h3>
                <div className="space-y-4 md:space-y-6 text-white/90 font-light leading-relaxed text-sm md:text-lg">
                  <p>{t.bioText1}</p>
                  <p>{t.bioText2}</p>
                  <p>{t.bioText3}</p>
                  <p>{t.bioText4}</p>
                  <p>{t.bioText5}</p>
                </div>
              </div>
              <div>
                <h3 className="font-serif text-2xl md:text-4xl font-light mb-4 md:mb-6 text-white">{t.artistStatement}</h3>
                <blockquote className="italic text-white/90 font-light leading-relaxed text-sm md:text-xl border-l-4 border-white/30 pl-4 md:pl-8">
                  "{t.quote}"
                </blockquote>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="min-h-screen bg-gradient-to-b from-gray-900 to-black py-12 md:py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-serif text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-light mb-12 md:mb-16 text-white">{t.contact}</h2>
          <div className="space-y-8 md:space-y-10">
            <p className="text-lg md:text-2xl font-light text-white/90 max-w-3xl mx-auto leading-relaxed">{t.contactText}</p>
            
            {/* Contact Links */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <a
                href="https://t.me/elenakutuzovaart"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-3 text-base md:text-xl font-light border-2 border-white/30 px-6 md:px-8 py-3 md:py-4 hover:bg-white hover:text-black transition-all duration-500 rounded-2xl group"
              >
                <Send className="w-5 h-5 group-hover:scale-110 transition-transform duration-300" />
                <span>{t.telegram}</span>
              </a>
              
              <a
                href="mailto:kutuzovaart@mail.ru"
                className="inline-flex items-center space-x-3 text-base md:text-xl font-light border-2 border-white/30 px-6 md:px-8 py-3 md:py-4 hover:bg-white hover:text-black transition-all duration-500 rounded-2xl group"
              >
                <Mail className="w-5 h-5 group-hover:scale-110 transition-transform duration-300" />
                <span>{t.email}</span>
              </a>
            </div>
            
            {/* Email address display */}
            <p className="text-sm md:text-base text-white/70 font-light">
              kutuzovaart@mail.ru
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
